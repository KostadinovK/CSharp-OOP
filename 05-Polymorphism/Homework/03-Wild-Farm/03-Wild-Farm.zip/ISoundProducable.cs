﻿using System;
using System.Collections.Generic;
using System.Text;


public interface ISoundProducable
{
    string ProduceSound();
}
