﻿using System;
using System.Collections.Generic;
using System.Text;


public class AngryMood : Mood
{
    public override string MoodName
    {
        get => "Angry";
        protected set
        {
        }
    }
}

