﻿using System;
using System.Collections.Generic;
using System.Text;


public class HappyMood : Mood
{
    public override string MoodName {
        get => "Happy";
        protected set {
        }
    }
}
