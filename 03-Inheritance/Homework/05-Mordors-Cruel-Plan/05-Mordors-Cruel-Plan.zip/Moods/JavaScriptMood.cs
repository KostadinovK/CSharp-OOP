﻿using System;
using System.Collections.Generic;
using System.Text;

class JavaScriptMood : Mood
{
    public override string MoodName {
        get => "JavaScript";
        protected set {
        }
    }
}
