﻿using System;
using System.Collections.Generic;
using System.Text;


public abstract class Food
{
    public abstract  int HappinessPoints { get; protected set; }

}

