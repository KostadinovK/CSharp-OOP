﻿using System;
using System.Collections.Generic;
using System.Text;

public class Lembas : Food
{
    public override int HappinessPoints {
        get => 3;
        protected set { }
    }
}

