﻿using System;
using System.Collections.Generic;
using System.Text;

public delegate void JobDoneDelegate(IJob sender);
