﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IEmployee
{
    string Name { get; set; }
    int WorkHoursPerWeek { get; }
}
