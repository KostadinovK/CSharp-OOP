﻿using System;
using System.Collections.Generic;
using System.Text;


public delegate void KingsAttackEventHandler();
