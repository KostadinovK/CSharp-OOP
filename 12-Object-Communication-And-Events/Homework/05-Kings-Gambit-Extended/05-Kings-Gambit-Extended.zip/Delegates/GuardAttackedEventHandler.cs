﻿using System;
using System.Collections.Generic;
using System.Text;

public delegate void GuardAttackedEventHandler(IGuard sender);