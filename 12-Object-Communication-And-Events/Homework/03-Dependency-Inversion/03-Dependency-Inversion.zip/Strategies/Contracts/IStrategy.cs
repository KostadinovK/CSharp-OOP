﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IStrategy
{
    int Calculate(int firstOperand, int secondOperand);
}
