﻿using System;

namespace _02_ExtendedDatabase
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
