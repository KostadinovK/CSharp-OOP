﻿using System;

namespace _01_Database
{
    public class Program
    {
        public static void Main()
        {

        }
    }
}
