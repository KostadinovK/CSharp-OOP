﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniRestaurant.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
