﻿using System;
using System.Collections.Generic;
using System.Text;
using _03BarracksFactory.Contracts;

namespace _03BarracksFactory.Core.Commands
{
    public class RetireCommand : Command
    {
        public RetireCommand(string[] data, IRepository repository, IUnitFactory unitFactory) : base(data, repository, unitFactory)
        {
        }

        public override string Execute()
        {
            try
            {
                Repository.RemoveUnit(Data[1]);
            }
            catch (ArgumentException e)
            {
                return e.Message;
            }

            return $"{Data[1]} retired!";
        }
    }
}
