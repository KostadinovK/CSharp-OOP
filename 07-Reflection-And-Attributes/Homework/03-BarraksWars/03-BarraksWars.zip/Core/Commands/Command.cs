﻿using System;
using System.Collections.Generic;
using System.Text;
using _03BarracksFactory.Contracts;

namespace _03BarracksFactory.Core.Commands
{
    public abstract class Command : IExecutable
    {
        private string[] data;
        private IRepository repository;
        private IUnitFactory unitFactory;

        protected string[] Data
        {
            get => data;
            set { data = value; }
        }

        protected IRepository Repository
        {
            get => repository;
            set { repository = value; }
        }

        protected IUnitFactory UnitFactory
        {
            get => unitFactory;
            set { unitFactory = value; }
        }

        protected Command(string[] data, IRepository repository, IUnitFactory unitFactory)
        {
            Data = data;
            Repository = repository;
            UnitFactory = unitFactory;
        }

        public abstract string Execute();
    }
}
