﻿using System;
using System.Collections.Generic;
using System.Text;


public class EpicRarity : Rarity
{
    public override int DamageMultiple => 5;
}
