﻿using System;
using System.Collections.Generic;
using System.Text;


public abstract class Rarity : IRarity
{
    public abstract int DamageMultiple { get;}

}
