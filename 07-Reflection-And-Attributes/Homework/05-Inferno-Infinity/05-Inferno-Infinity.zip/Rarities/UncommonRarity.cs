﻿using System;
using System.Collections.Generic;
using System.Text;


public class UncommonRarity : Rarity
{
    public override int DamageMultiple => 2;
}
