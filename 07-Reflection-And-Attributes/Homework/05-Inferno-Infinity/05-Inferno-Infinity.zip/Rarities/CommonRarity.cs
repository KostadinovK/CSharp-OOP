﻿using System;
using System.Collections.Generic;
using System.Text;

public class CommonRarity : Rarity
{
    public override int DamageMultiple => 1;
}
