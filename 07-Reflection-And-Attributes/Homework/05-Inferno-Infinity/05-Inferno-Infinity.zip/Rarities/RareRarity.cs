﻿using System;
using System.Collections.Generic;
using System.Text;


public class RareRarity : Rarity
{
    public override int DamageMultiple => 3;
}
