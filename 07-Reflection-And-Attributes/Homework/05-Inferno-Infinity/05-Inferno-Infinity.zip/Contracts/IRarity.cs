﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IRarity
{
    int DamageMultiple { get; }
}
