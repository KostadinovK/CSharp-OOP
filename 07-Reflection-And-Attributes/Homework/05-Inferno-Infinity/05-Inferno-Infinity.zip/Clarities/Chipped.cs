﻿using System;
using System.Collections.Generic;
using System.Text;


public class Chipped : Clarity
{
    public override int Bonus => 1;
}
