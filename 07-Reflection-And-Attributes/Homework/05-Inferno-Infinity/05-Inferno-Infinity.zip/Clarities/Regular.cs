﻿using System;
using System.Collections.Generic;
using System.Text;


public class Regular : Clarity
{
    public override int Bonus => 2;
}
