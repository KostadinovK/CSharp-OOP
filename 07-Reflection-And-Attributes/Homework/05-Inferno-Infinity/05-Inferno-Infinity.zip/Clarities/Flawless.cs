﻿using System;
using System.Collections.Generic;
using System.Text;


public class Flawless : Clarity
{
    public override int Bonus => 10;
}
