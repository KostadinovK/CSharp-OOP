﻿using System;
using System.Collections.Generic;
using System.Text;

public abstract class Clarity : IClarity
{
    public abstract int Bonus { get; }
}
