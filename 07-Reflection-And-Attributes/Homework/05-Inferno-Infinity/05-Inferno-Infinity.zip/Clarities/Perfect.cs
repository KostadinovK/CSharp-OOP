﻿using System;
using System.Collections.Generic;
using System.Text;


public class Perfect : Clarity
{
    public override int Bonus => 5;
}
