﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main()
        {

        }
    }
}

