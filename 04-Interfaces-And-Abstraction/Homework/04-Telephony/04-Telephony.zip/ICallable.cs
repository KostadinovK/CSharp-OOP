﻿using System;
using System.Collections.Generic;
using System.Text;


public interface ICallable
{
    string Call(string phone);
}

