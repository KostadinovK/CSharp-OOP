﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IAddable
{
    int Add(string toAdd);
}

